<nav id="barra" class="navbar sticky-top navbar-expand-lg navbar-light" style="background-color: #46464666;" >
  <a class="nav-link" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/img/Mixi-logo.png')); ?>"class="d-block w-300" alt="img" height="55"></a> 

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent1">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item ">
        <a class="nav-link" style="color:#ffffff;" href="<?php echo e(url('/')); ?>">Inicio</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" style="color:#ffffff;" href="<?php echo e(route('contenidos')); ?>">Contenidos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" style="color:#ffffff;" href="<?php echo e(route('nosotros')); ?>">Nosotros</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" style="color:#ffffff;" href="<?php echo e(route('contacto')); ?>">Contáctanos</a>
      </li>
    </ul>


  <?php if(auth()->guard()->guest()): ?>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                  <a class="nav-link" style="color:#ffffff;" href="<?php echo e(route('login')); ?>">
                      Iniciar sesión
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" style="color:#ffffff;" href="<?php echo e(route('register')); ?>">
                      Registrarse
                  </a>
              </li>
          </ul>
      </div>
  <?php else: ?>
    <li class="nav <?php echo e(Request::is('materias') && ! Request::is('createMaterias')? 'active' : ''); ?>">
    <li class="nav <?php echo e(Request::is('createMaterias') ? 'active' : ''); ?>">
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">

            <li class="nav-item">
              <a class="nav-link" style="color:#ffffff;" href="<?php echo e(url('/home')); ?>">                                    
                  Panel Administrador
              </a>
              

              <li class="nav-item dropdown">

                  <a class="nav-link dropdown-toggle" style="color:#ffffff;" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    ¡Hola   <?php echo e(Auth::user()->name); ?>!
                  </a>                    
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink"> 
                  <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Cerrar sesión</a>                      
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo e(csrf_field()); ?>

                  </form>
                  </div>
              </li>
          </ul>
      </div>
  <?php endif; ?>
</nav>




<script>
  $(window).scroll(function(){
    if ($("#barra").offset().top > 20) {
      $("#barra").addClass('bg-primary');
    } else {
      $("#barra").removeClass('bg-primary');
    }
    });
</script>