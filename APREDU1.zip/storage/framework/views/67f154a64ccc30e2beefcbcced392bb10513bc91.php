<?php $__env->startSection('title', 'APREDU'); ?>
<?php $__env->startSection('content'); ?>


<br>
<div class="container">
    <div class="jumbotron">
        <h1 class="display-4">Contáctanos</h1>
        <hr class="my-4">
        <h1 class="display-9">Redes sociales</h1>
<br>
        <div class="row">
  <div class="col-sm-3">
    <a target="_blank" href= "https://www.facebook.com/UNION-Organization-101504898645648/"> <div align="center"><img src="<?php echo e(url('/img/facebook.png')); ?>"class="d-block w-300"  alt="img" height="75"></div></a>
  </div>
    <div class="col-sm-3">
    <a target="_blank" href= "https://www.twitter.com"> <div align="center"><img src="<?php echo e(url('/img/twitter.png')); ?>"class="d-block w-300"  alt="img" height="75"></div></a> 
     </div>
    <div class="col-sm-3">
    <a target="_blank" href= "https://www.gmail.com"> <div align="center"><img src="<?php echo e(url('/img/gmail.png')); ?>"class="d-block w-300"  alt="img" height="75"></div></a> 
</div>
<div class="col-sm-3">
<a target="_blank" href= "https://www.instagram.com"> <div align="center"><img src="<?php echo e(url('/img/instagram.png')); ?>"class="d-block w-300"  alt="img" height="75"></div></a> 
</div>
</div>

        <br>

</div>


</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>