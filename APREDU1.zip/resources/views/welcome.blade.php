@extends('layouts.app')
@section('title', 'APREDU')
@section('content')

<div class="row">
  <div class="col-sm-7">
    <br>
        <div align="center"><img src="{{url('/img/Inicio01.png')}}"class="d-block w-300 img-fluid" alt="img" height="500"></div>
  </div>
  <div class="col-sm-4">
  <div align="center"><img src="{{url('/img/Home.png')}}"class="d-block w-300 img-fluid" alt="img" height="500"></div>
  <br>
  <div class="center"><a href="https://play.google.com/store" class="btn btn-primary btn-lg active btn-lg btn-block" role="button" target="_blank" aria-pressed="true">Descarga Aquí en Playstore</a></div>
  <br>
  <div class="center"><a href="https://www.apple.com/mx/app-store/" class="btn btn-primary btn-lg active btn-lg btn-block" role="button" target="_blank" aria-pressed="true">Descarga Aquí en AppStore</a></div>

  </div>
</div>

<br>
  <br>
  <br>

</div>
</div>
</div>


@endsection