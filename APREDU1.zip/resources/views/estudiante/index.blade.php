@extends('layouts.app2')
@section('title', 'Sobre Nosotros')
@section('content')




<br>
<br>
<br>

<div class="container">
    <div class="jumbotron">
        <h1 class="display-4">¡Bienvenido {{ Auth::user()->name }}!</h1>
        <hr class="my-4">
        <p class="lead">Diviértete aprendiendo.</p>
        <br>
</div>




<br>
<br>
</div>
</div>
</div>

@endsection