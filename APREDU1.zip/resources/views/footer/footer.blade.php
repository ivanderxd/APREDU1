<!-- Footer -->
<footer class="page-footer font-small unique-color-dark" style="background-color  : #46464666; ">

  <div style="background-color: ##040506;">
    <div class="container">

      <!-- Grid row-->
      <div class="row py-4 d-flex align-items-center">

        <!-- Grid column -->
        <!-- Grid column -->



      </div>
      <!-- Grid row-->

    </div>
  </div>

  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-5" >

    <!-- Grid row -->
    <div class="row mt-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold" style="color:#ffffff;">APREDU</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto  "  style="width: 60px; ">
        <p style="color: #fff;" >Nuestra finalidad es dar material de apoyo a escuelas de nivel básico para reforzar los temas vistos en clases.</p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold " style="color:#ffffff;">Union</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a style="color:#fff;" href="{{url('/nosotros')}}" > Sobre Nosotros </a>
        </p>

        <p>
          <a style="color:#fff;" href="{{url('/contacto')}}" > Contáctanos </a>
        </p>


      </div>
      <!-- Grid column -->

      

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold" style="color:#ffffff;">Contacto</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <!-- Facebook -->
        <a class="fb">
            <a style="color:#fff;" target="_blank" href= "https://www.facebook.com">
              <p><i class="fa fa-facebook-square fa-2x" style="color:#fff;" aria-hidden="true"></i> Union </p>
            </a>
        </a>

        <!-- Twitter -->
        <a class="tw">
            <a style="color:#fff;" target="_blank" href= "https://www.twitter.com">
            <p><i class="fa fa-twitter-square fa-2x" style="color:#fff;" aria-hidden="true"></i> Union </p>
            </a>
        </a>

        <!--Gmail -->
        <a class="li-ic">
            <a style="color:#fff;" target="_blank" href= "https://www.gmail.com">
              <p><i class="fa fa-envelope-square fa-2x" style="color:#fff;" aria-hidden="true"></i> Union </p>
            </a>
          </a>  
        <!-- YouTube -->

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->
<br>
<br>
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3"  style="background-color: #007ca6;">© 2021 Copyright:
    <a href="#" style="color:#ffffff;" > Union.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->